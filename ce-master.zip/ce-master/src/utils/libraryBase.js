const lib = {
    jspreadsheet: {}
};

export default lib;