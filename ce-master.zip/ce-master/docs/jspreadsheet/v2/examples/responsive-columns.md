title:  Jspreadsheet | Examples | Responsive Layout
keywords: Jexcel, jquery, javascript, bootstrap, table design, spreadsheet, CSV, table, grid, autocomplete, customization, column
description: Creating a more responsive layout on jexcel

[Back to Examples](/jspreadsheet/v2/examples)

# Responsive columns

The Jspreadsheet jquery plugin brings a more responsive column types.

![](img/iphone.png)

[Open this table only in a new window](/jspreadsheet/v2/examples/mobile)

